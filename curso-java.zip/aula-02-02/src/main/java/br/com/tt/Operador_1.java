package br.com.tt;

public class Operador_1 {

	public static void main(String[] args) {
		System.out.println("Operadores");
		System.out.println("Soma: " + 1 + 5);
		System.out.println("Soma: " + (1 + 5));
		System.out.println("Soma: " + (1 + 5));
		Long soma = 1L + 5L;
		System.out.println("Soma: " + soma);
		// primeiro atribui
		// depois imvrementa
		Long incremento = soma++;
		// soma++
		// igual a
		// incremento = soma;
		// soma = soma + 1

		System.out.println("Incremento " + incremento);
		System.out.println("Incremento " + soma);

		System.out.println("Pre Incremento");
		Long pre = 3L;
		System.out.println("Pre " + ++pre);
	}

}
