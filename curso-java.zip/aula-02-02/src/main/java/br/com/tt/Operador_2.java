package br.com.tt;

public class Operador_2 {
	public static void main(String[] args) {
		Cliente c1 = new Cliente();
		Cliente c2 = new Cliente();
		System.out.println(c1 == c2);
		if (c1 == c2) {
			System.out.println("iguais");
		} else {
			System.out.println("diferentes");
		}

		System.out.println(c1.equals(c2));

		System.out.println(true & true);

		int val = 1;

		System.out.println(val == val & val == val++);
		System.out.println(val);

		System.out.println(val == 1 || val == val++);
		System.out.println(val);
		String result = "";
		if (1 != 2) {
			result = "Sim";
		} else {
			result = "N�o";
		}
		// Igual
		result = 1 != 2 ? "Sim" : "N�o";
		System.out.println(result);

		int valor = 5;

		valor = valor + 3;
		// igual
		valor += 3;
		System.out.println("valor: " + valor);

	}
}
