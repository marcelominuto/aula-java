package br.com.tt;

public class Sistema {
	public static void main(String... args) {
		comprar(50D,"Pedro","arroz","carne","c");
	}
private static void comprar(
	double valor,String nome,String... prods){
	System.out.println("Nome: "+nome);
	System.out.println("Valor: "+valor);
	System.out.println("Produtos: ");
		for (String produto : prods) {
		System.out.println("\t - "+produto);
		}
	}



}
