package br.com.tt;

public class TesteIf_4 {
	public static void main(String[] args) {
		int idade = 77;
		if(idade < 16){
System.err.println("Idade N�o Valida Para Votar");
}else if((idade>=16 && idade<18)||(idade > 70)){
System.out.println("Voto Opcional");
		}else{
		System.out.println("Voto Obrigatorio");
		}
	}}
