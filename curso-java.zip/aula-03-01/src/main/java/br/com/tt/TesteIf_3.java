package br.com.tt;

import javax.sql.rowset.spi.SyncResolver;

public class TesteIf_3 {

	public static void main(String[] args) {
		Integer idade = -9;
		if (idade < 0) {
			System.err.println("Idade N�o Valida");
		} else if (idade < 16) {
			System.out.println("N�o � permitido");
		} else if (idade < 18) {
			System.out.println("Opcional");
		} else if (idade < 70) {
			System.out.println("Obrigatorio");
		} else {
			System.out.println("Opcional");
		}
	}

}
