package br.com.tt;

public class TesteIf_1 {

	public static void main(String[] args) {
		Integer idade = 15;
		if (idade >= 18) {
			System.out.println("Maior de Idade");
		} else {
			System.out.println("Menor de Idade");
		}

	}

}
