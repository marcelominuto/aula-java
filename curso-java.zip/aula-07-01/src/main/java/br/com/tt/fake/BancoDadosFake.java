package br.com.tt.fake;

import java.util.ArrayList;
import java.util.List;

import br.com.tt.model.Cliente;
import br.com.tt.model.Funcionario;

public class BancoDadosFake {
public static List<Cliente> 
                   clientes = new ArrayList<>();
public static List<Funcionario> 
                  funcionarios=new ArrayList<>();

}
