package br.com.tt.controller;

import br.com.tt.model.Cliente;

public class Sistema_2 {
	public static void main(String[] args) {
		Cliente cliente = new Cliente();
		cliente.setId(1L);
		cliente.setNome("Maria");
		cliente.setSaldo(10D);
		
	}
}
