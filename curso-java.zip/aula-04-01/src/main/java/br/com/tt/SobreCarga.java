package br.com.tt;

import java.util.ArrayList;
import java.util.List;

public class SobreCarga {
	static List<String> nomes = new ArrayList<>();

	public static void main(String[] args) {
		String nome = "";
		nome = pesquisar("Ana");
		nome = pesquisar(2);
		System.out.println("id 2: " + nome);
		nome = pesquisar();
		System.out.println("todos: " + nome);
		nome = pesquisar('r', 2);
		System.out.println("letra e id: " + nome);
		nome = pesquisar(3, 'r');
		System.out.println("id e letra: " + nome);
	}

	private static String pesquisar(int id, char letra) {
		return pesquisar(letra, id);
	}

	private static String pesquisar(char letra, int id) {
		String retorno = null;
		for (String nome : nomes) {
			if (id >= nome.length()) {
				continue;
			}
			if (nome.charAt(id) == letra) {
				retorno = nome;
				break;
			}
		}
		return retorno;
	}

	private static String pesquisar() {

		return nomes.toString();
	}

	private static String pesquisar(int id) {

		return nomes.get(id);
	}

	private static String pesquisar(String nome) {

		return null;
	}

	static {
		nomes.add("Ana");
		nomes.add("Pedro");
		nomes.add("Maria");
		nomes.add("Leo");
	}

}
