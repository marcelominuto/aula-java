package br.com.tt;

public class Programa {

	public static void main(String[] args) {
		/*
		 * Esse � o Meu sistema com comentetario para varias linhas
		 */
		System.out.println("INICIANDO O SISTEMA");

		// Variavel do tipo Texto
		String nome = "Paulo Heck";
		System.out.println("Meu Nome � " + nome);

		// Variavel do tipo Inteiro
		Integer idade = 18;
		System.out.println("Idade = " + idade);
		
		Double salario = 1500000D;
		System.out.println("Sal�rio: "+salario);

	}

}
