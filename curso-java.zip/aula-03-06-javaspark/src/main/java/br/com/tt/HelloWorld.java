package br.com.tt;

import static spark.Spark.*;

import java.util.Date;

public class HelloWorld {
	public static void main(String[] args) {
		 String page1 = "<h1><center>Minha pag";
		 page1 += "</h1></center>";
		 page1 += "Data: "+ new Date();
		final String htmlPage = page1;
		System.out.println(htmlPage);
		get("/hello", (req, res) -> htmlPage);
	}
}
