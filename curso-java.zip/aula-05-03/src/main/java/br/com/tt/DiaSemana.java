package br.com.tt;

public enum DiaSemana {
SEGUNDA(2,"Segunda"),
TERCA(3,"Ter�a"),
QUARTA(4,"Quarta"),
QUINTA(5,"Quinta"),
SEXTA(6,"Sexta"),
SABADO(7,"Sabado"),
DOMINGO(1,"Domingo");
	int dia;
	String desc;
	DiaSemana(int dia, String desc){
		this.dia = dia;
		this.desc = desc;
	}
}
