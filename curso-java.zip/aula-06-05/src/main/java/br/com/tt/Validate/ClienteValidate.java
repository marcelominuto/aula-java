package br.com.tt.Validate;

import br.com.tt.exception.ClienteException;
import br.com.tt.model.Cliente;

public class ClienteValidate {
	private static final String NOME_VALIDA = "Nome necessita 5 Letras";
	private static final String CPF_VALIDA = "Nome necessita 11 digitos";

	public void nome(Cliente cli) throws ClienteException {
		if (cli.getNome().length() < 4) {
			throw new ClienteException(NOME_VALIDA);
		}
	}

	public void cpf(Cliente cli) throws ClienteException   {
		if (cli.getCpf().length() != 11) {
			throw	new ClienteException(CPF_VALIDA);
		}
	}
}
