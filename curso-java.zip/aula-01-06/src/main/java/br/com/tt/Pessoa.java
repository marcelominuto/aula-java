package br.com.tt;

public class Pessoa {
	String nome;
	String cpf;
	String end;

}
