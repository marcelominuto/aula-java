package br.com.tt;

public class Programa {

	public static void main(String[] args) {
		
		Pessoa p1 = new Pessoa();
		p1.nome = "Maria";
		p1.cpf= "03279246955";
		p1.end = "Rua A";

	}

}
