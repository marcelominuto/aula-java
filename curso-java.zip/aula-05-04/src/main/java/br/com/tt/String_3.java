package br.com.tt;

public class String_3 {
public static void main(String[] args) {
StringBuilder sb = new StringBuilder("Inicar st");
sb.append(" ola ").append("pois").append(" se");
System.out.println(sb);
System.out.println(sb.toString().toUpperCase());
System.out.println(sb.reverse());
}
}
