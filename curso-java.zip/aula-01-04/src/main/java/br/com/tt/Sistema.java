package br.com.tt;

import javax.swing.JOptionPane;

public class Sistema {
	public static void main(String[] args) {
		// \t cria um tap
		// para realiza o print da barra \\
		System.out.println("\n\n\t\\Iniciando o Sistema\\");
String nome = null;
nome=JOptionPane.showInputDialog("Dig o Nome");
JOptionPane.showMessageDialog(
		null, nome.toUpperCase());

String strIdade =
   JOptionPane.showInputDialog("Idade");
Integer idade = Integer.valueOf(strIdade);
if(idade >= 18){
	       JOptionPane.showMessageDialog(
	    		   null, nome+": Maior de Idade");
			
		}else{
			JOptionPane.showMessageDialog(
				null, nome+": Menor de Idade");

		}
	}

}
