package br.com.tt;

public class Sistema {

	public static void main(String[] args) {
		try {
			cadastro(5);
		}catch (IndexOutOfBoundsException e) {
			String valor = e.getMessage();
			System.err.println(
					valor + " N�o � Valido o ID");
		} 
		catch (Exception e) {
			System.err.println(e.getMessage());
		}catch (Throwable e) {
			System.err.println(e.getMessage());
		}
	}

	public static void cadastro(int i) {
		String[] clientes = new String[5];
		clientes[i] = "Pedro";
	}
}
