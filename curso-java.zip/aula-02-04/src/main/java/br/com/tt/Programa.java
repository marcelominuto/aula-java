package br.com.tt;


import static java.lang.Math.PI;
import static java.lang.System.*;

public class Programa {
	public static void main(String[] args) {
		out.println("Teste");
		double pi = PI;
	}
}
