package br.com.tt;

public class Sistema {
	final String teste;

	public Sistema() {
		teste = "a";
	}

	public static void main(String[] args) {
		final double pi = 3.14;
    // pi = 3.50; // n�o � possivel pois � final

		final String nome = "Pedro";
		// nome = "maria";// pois � final

		final Cliente c1 = new Cliente(1L);
		c1.setNome("Maria");
		c1.setNome("Juca");
		
		//c1 = new Cliente(2L); // pois � final
		
		
	}
	

}
