package br.com.tt.model;

public class Animal {

	private String nome;
	String especie;
	Pessoa dono;

	public void setNome(String nome) {

		if (nome.length() >= 3) {
			this.nome = nome;
		}
	}

	public String getNome() {
		return nome;
	}

	public String getEspecie() {
		return especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

	public Pessoa getDono() {
		return dono;
	}

	public void setDono(Pessoa dono) {
		this.dono = dono;
	}
	
	

}
