package br.com.tt;

public class Programa {
	public static void main(String[] args) {
		Cliente c1 = null;
		System.out.println(c1);
		c1 = new Cliente();
		System.out.println(c1);
		System.out.println(c1.nome);
		c1.nome = new String("Maria");
		//igual a linha abaixo
		c1.nome = "Maria";
		System.out.println(c1.nome);
		c1 = null;
		if(c1 != null){ // para evitar o nullpoiter
		System.out.println(c1.nome);
		}
		
		c1 = new Cliente();
		c1 = new Cliente();
		Cliente c2 = c1;
		c1.nome = "Juca";
		System.out.println(c2.nome);
		
		System.out.println(c2.toString());
		System.out.println(c1.toString());
System.out.println(c1.getClass().getName());
System.out.println(
		Integer.toHexString(c1.hashCode())
		);
		
		
		
		
	}

}
