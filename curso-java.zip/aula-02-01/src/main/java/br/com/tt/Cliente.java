package br.com.tt;
/**
 * Ola sou a classe cliente
 * @author instrutor
 *
 */
public class Cliente {

	String nome;
	String cnpjCpf;
	String endereco;
	@Override
	public String toString() {
		return "Cliente [nome=" + nome + ", cnpjCpf=" + cnpjCpf + ", endereco=" + endereco + "]";
	}
	
	
	
}
