package br.com.tt;

public class Sistema {
	public static void main(String[] args) {
		new Animal();
		new Animal();
	}
}
