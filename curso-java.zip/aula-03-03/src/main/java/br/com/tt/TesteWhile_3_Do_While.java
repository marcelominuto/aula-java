package br.com.tt;

public class TesteWhile_3_Do_While {
	public static void main(String[] args) {
	
		int i = 1; //incrementa ate 10
//	int i = 20; //somente uma ves pois � false
		do {
		// primeiro printa
			System.out.println(i);
			i++;
		//depois verfica se preciasa novamente
		} while (i <= 10);
	}

}
