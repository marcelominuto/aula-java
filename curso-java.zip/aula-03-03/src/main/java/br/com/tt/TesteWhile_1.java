package br.com.tt;

public class TesteWhile_1 {
	public static void main(String[] args) {

		Integer i = 0;
		while (i <= 10) {
			System.out.println(i);
			i++;
		}
	}

}
