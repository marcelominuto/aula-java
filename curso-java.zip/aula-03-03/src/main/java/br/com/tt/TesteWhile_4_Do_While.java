package br.com.tt;

import java.awt.JobAttributes;

import javax.swing.JOptionPane;

public class TesteWhile_4_Do_While {
	public static void main(String[] args) {
		String nome ="Iniciando O sistema";
		do{
			System.out.println(nome);
	nome=JOptionPane.showInputDialog("Nome:");
	nome = "Nome: "+nome;
		}while(!nome.endsWith("sair"));
		
		System.out.println("Fim do Sistema");
	}
}
