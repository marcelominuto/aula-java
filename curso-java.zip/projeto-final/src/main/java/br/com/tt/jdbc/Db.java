package br.com.tt.jdbc;

public class Db {

}
