package br.com.tt;

public class TesteFor_7 {
	public static void main(String[] args) {

		String nome = "TargetTrust";
for (int i = nome.length() - 1; i >= 0; i--) {
			System.out.print(nome.charAt(i));

		}

	}
}
