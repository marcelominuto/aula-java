package br.com.tt;

public class TesteFor_6 {
	public static void main(String[] args) {

		String nome = "TargetTrust";
		for (int i = 0; i < nome.length(); i++) {
			System.out.println(nome.charAt(i));

		}

	}
}
