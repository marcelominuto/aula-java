package br.com.tt;

public class Ternario {
	public static void main(String[] args) {
		Integer val = 5;
String resultado=val > 0 ?"Posistivo":"Negativo";
System.out.println(resultado);
System.out.println(val > 0 ?"Pos":"Neg");
	}
}
